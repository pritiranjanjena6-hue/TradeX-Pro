# TradeX Pro Android starter

This is an Android Studio project that wraps a mobile trading terminal in Android WebView. It uses TradingView Lightweight Charts 5.0.8 from its official public CDN.

## Included
- Android app shell (application ID `com.tradexpro.app`)
- Lightweight Charts candlestick chart
- Public Binance REST ticker/candle integration for BTCUSDT, ETHUSDT and BNBUSDT
- Market selector placeholders for metals, indices, commodities and forex
- SMA/RSI display, JavaScript custom indicator editor
- SMA crossover strategy settings and simplified historical backtest
- Paper-trading ticket (does not send real orders)

## Important limitations
- This is a starter build, not a production broker terminal.
- Non-crypto instruments require a licensed market-data provider and API credentials. The app intentionally does not invent live prices for those markets.
- The backtester is a simplified long-only SMA crossover model. It is not a full Pine Script engine and does not model slippage, funding, partial fills or exchange execution.
- Custom indicator code runs locally in the WebView. Only run code you trust.
- No exchange keys or real-order execution are included.

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

For a signed release APK: Build > Generate Signed Bundle / APK, create or select a keystore, then choose APK.

## Network notes
The charting library is loaded from `unpkg.com`; crypto market data is fetched from Binance public endpoints. Internet access is required. If a provider blocks access in a region or network, configure another data provider before release.
